# encoding: utf-8
require 'rubygems'
require 'telegram/bot'


def run_book_bot
  token = '5317272479:AAHbCrTqxUCu_0r74cpFu4XUSmX3WaShXHA'

  Telegram::Bot::Client.run(token) do |bot|
    bot.listen do |message|
      case message
        when Telegram::Bot::Types::CallbackQuery
          # Here you can handle your callbacks from inline buttons
          if message.data == 'books'
            books = ['book1', 'book2', 'book3', 'book4', 'book5', 'book6']
            kb = [
              Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Замовити книгу', callback_data: 'order_book'),
            ]
            markup = Telegram::Bot::Types::InlineKeyboardMarkup.new(inline_keyboard: kb)
            bot.api.send_message(chat_id: message.from.id, text: "#{books.join("\n")}", reply_markup: markup)
          elsif message.data == 'magazines'
            magazines = ['magazine1', 'magazine2', 'magazine3', 'magazine4', 'magazine5', 'magazine6']
            kb = [
              Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Замовити журнал', callback_data: 'order_magazine'),
            ]
            markup = Telegram::Bot::Types::InlineKeyboardMarkup.new(inline_keyboard: kb)
            bot.api.send_message(chat_id: message.from.id, text: "#{magazines.join("\n")}", reply_markup: markup)
          elsif message.data == "order_book"
            bot.api.send_message(chat_id: message.from.id, text: "Введіть /book назву книги")
          elsif message.data == "order_magazine"
            bot.api.send_message(chat_id: message.from.id, text: "Введіть /food назву журналу")
          end
        when Telegram::Bot::Types::Message
          case message.text
            when '/start'
              kb = [
                Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Переглянути список книг', callback_data: 'books'),
                Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Переглянути список журналів', callback_data: 'magazines'),
                Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Замовити книгу', callback_data: 'order_book'),
                Telegram::Bot::Types::InlineKeyboardButton.new(text: 'Замовити журнал', callback_data: 'order_magazine'),
              ]
              markup = Telegram::Bot::Types::InlineKeyboardMarkup.new(inline_keyboard: kb)
              bot.api.send_message(chat_id: message.chat.id, text: "Ласкаво просимо, #{message.from.first_name}", reply_markup: markup)
            when '/stop'
              order.clear
                bot.api.send_message(chat_id: message.chat.id, text: "Дякуємо що були з нами, #{message.from.first_name}!")
            when '/ok'
              orders = Order.where(:user_id => message.from.id, :order_completed => 0)
              orders.each do |order_|
                order_.update({
                  order_completed: 1
                })
              end           
              bot.api.send_message(chat_id: message.chat.id, text: "Дякуємо що були з нами, очікуйте ваше замовлення.")
            else
                if message.text.start_with?("/book")
                  book_name = message.text.sub('/book ', '')
                  begin
                    found = Book.where(:name => book_name).first
                    bot.api.send_message(chat_id: message.chat.id, text: "Ви замовили #{found.name}, ціна #{found.price}")
                    new = Order.new({
                      is_book: 1,
                      ordered_id: found.id,
                      user_id: message.from.id,
                      order_completed: 0
                    })
                    if new.save
                      puts "ok"
                    elsif new.errors
                      puts new.errors.full_messages
                    end
                    orders = Order.where(:user_id => message.from.id, :order_completed => 0)
                    final_order = []
                    final_price = 0
                    orders.each do |item|
                      if item.is_book
                        ordered = Book.where(:id => item.ordered_id).first
                      else
                        ordered = Magazine.where(:id => item.ordered_id).first
                      end
                      final_order.push(ordered.name.to_s)
                      final_price += ordered.price.to_f.round(2)
                    end
                    bot.api.send_message(chat_id: message.chat.id, text: "Ваше замовлення #{final_order.join(', ')}, вартість #{final_price}.")
                    bot.api.send_message(chat_id: message.chat.id, text: "Введіть команду /ok для завершення.") 
                  end
                elsif message.text.start_with?("/magazine")
                  magazine_name = message.text.sub('/magazine ', '')
                  begin
                    found = Magazine.where(:name => magazine_name).first
                    bot.api.send_message(chat_id: message.chat.id, text: "Ви замовили #{found.name}, ціна #{found.price}")
                    new = Order.new({
                      is_magazine: 0,
                      ordered_id: found.id,
                      user_id: message.from.id,
                      order_completed: 0
                    })
                    if new.save
                      puts "ok"
                    elsif new.errors
                      puts new.errors.full_messages
                    end
                    orders = Order.where(:user_id => message.from.id, :order_completed => 0)
                    final_order = []
                    final_price = 0
                    orders.each do |item|
                      if item.is_magazine
                        ordered = Book.where(:id => item.ordered_id).first
                      else
                        ordered = Magazine.where(:id => item.ordered_id).first
                      end
                      final_order.push(ordered.name.to_s)
                      final_price += ordered.price.to_f.round(2)
                    end
                    bot.api.send_message(chat_id: message.chat.id, text: "Ваше замовлення #{final_order.join(', ')}, вартість #{final_price}.")
                    bot.api.send_message(chat_id: message.chat.id, text: "Введіть команду /ok для завершення.")  
                  rescue => exception
                    puts exception
                    bot.api.send_message(chat_id: message.chat.id, text: "Такого не існує")
                  end
                else
                  bot.api.send_message(chat_id: message.chat.id, text: "Вибачте, команда не підтримується, виберіть:
                    /start
                    /stop
                    /ok
                    /book назва
                    /magazine назва")
                end
            end
      end
    end
  end
end